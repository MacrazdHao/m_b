export default {
  test: '/11/test',
  getUserinfo: '',
}