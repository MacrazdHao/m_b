export const baseURL = 'https://www.veminar.net';
export const mockURL = 'http://192.168.0.104:3001/mock';