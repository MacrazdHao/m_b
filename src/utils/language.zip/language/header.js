export default {
  zh: {
  },
  en: {
  }
}