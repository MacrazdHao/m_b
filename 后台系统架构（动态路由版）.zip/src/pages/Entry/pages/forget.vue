<template>
  <div class="Forget">
    忘记密码
  </div>
</template>

<script>
export default {
  
}
</script>

<style lang="scss" scoped>
.Forget {

}
</style>