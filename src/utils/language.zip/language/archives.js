export default {
  zh: {
    detail: {
      archives: {
        title: '生涯档案'
      },
      follow: {
        title: '跟踪观察',
        step1Label: '第一阶段',
        step2Label: '第二阶段',
        step3Label: '第三阶段',
        step1Placeholder: '记录第一阶段学生的学习状况',
        step2Placeholder: '记录第二阶段学生的学习状况',
        step3Placeholder: '记录第三阶段学生的学习状况',
      },
      saveButton: '保存',
      cancelButton: '取消'
    }
  },
  en: {
  }
}