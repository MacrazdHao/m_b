// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue';
import App from './App';
import router from './router';
import i18n from './utils/language/index';
import store from './store/index';
import ElementUI from 'element-ui';
// import "./assets/font.css";
import "./assets/animate.css";
import 'element-ui/lib/theme-chalk/index.css'
import './utils/permission'

Vue.config.productionTip = false

// router.beforeEach((to, from, next) => {
//   console.log(to, from)
// })

Vue.use(ElementUI)

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  i18n,
  store,
  components: { App },
  template: '<App/>'
})
