export default {
  test: '/11/test',
  getMenu: '',
}