import animateMixin from './animate';
import languageMixin from './language';
import redirectMixin from './redirect';

export {
  animateMixin,
  languageMixin,
  redirectMixin
}