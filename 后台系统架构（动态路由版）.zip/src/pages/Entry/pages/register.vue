<template>
  <div class="Register">
    注册
  </div>
</template>

<script>
export default {
  
}
</script>

<style lang="scss" scoped>
.Register {

}
</style>