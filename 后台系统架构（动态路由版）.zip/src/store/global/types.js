export default {
  RESET_STATE: 'RESET_STATE',
  SET_MENU: 'SET_MENU',
}