export default {
  zh: {
    title: '知识中心',
    fileTips: '以下的是生涯文档',
    downloadButton: '下载',
  },
  en: {
    title: 'myFellas'
  }
}