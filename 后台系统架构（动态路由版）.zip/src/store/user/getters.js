export default {
  userinfo(state) {
    return state.userinfo;
  },
  messages(state) {
    return state.messages;
  }
}