<template>
  <div class="Error404">
    404
  </div>
</template>

<script>
export default {
  
}
</script>

<style lang="scss" scoped>
.Error404 {

}
</style>