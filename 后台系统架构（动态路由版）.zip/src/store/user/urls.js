export default {
  test: '/11/test',
  login: '/user/login',
  getUserinfo: '',
  getMessages: '',
}