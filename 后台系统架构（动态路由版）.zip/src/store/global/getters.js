export default {
  menu(state) {
    return state.menu;
  }
}