export default {
  zh: {
    title: 'myFellas'
  },
  en: {
    title: 'myFellas'
  }
}