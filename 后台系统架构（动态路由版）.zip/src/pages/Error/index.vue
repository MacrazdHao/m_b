<template>
  <div class="Error">
    错误
    <router-view />
  </div>
</template>

<script>
export default {
  
}
</script>

<style lang="scss" scoped>
.Error {

}
</style>